module wdp-war

go 1.21

require github.com/valyala/fasthttp v1.71.0

require (
	github.com/andybalholm/brotli v1.2.1 // indirect
	github.com/klauspost/compress v1.18.6 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
)
